package test;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ProductCalculationsTest {
    @Test
    public void GetVat_WithValidData_ReturnCorrectValue() {
        ProductCalculations calculations = new ProductCalculations(1000);

        assertEquals(150.0, calculations.GetVat(), 0.001);
    }

    @Test
    public void GetTotal_WithValidData_ReturnsCorrectValue() {
        ProductCalculations calculations = new ProductCalculations(1000);

        assertEquals(1200.0, calculations.GetTotal(), 0.001);
    }
}
