public class ST10515811_PROG6112_Exam {
    public static void main(String[] args) {
        String[] productNames = {
            "Sealy",
            "Serta",
            "Tempur"
        };

        int[][] monthlySales = {
            {120, 135, 150},
            {110, 125, 140},
            {130, 145, 160}
        };

        Product product = new Product(productNames, monthlySales);
        PrintProduct printer = new PrintProduct();
        printer.printReport(productNames, monthlySales, product);
    }
}
