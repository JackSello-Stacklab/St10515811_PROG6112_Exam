import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;

public class ProductTest {
    public void GetTotalProductsSales_WithValidData_ReturnsCorrectValue() {
        String[] names = {"Sealy", "Serta", "Tempur"};
        int[][] sales = {
            {10, 20, 30},
            {15, 25, 35},
            {20, 30, 40}
        };
        Product product = new Product(names, sales);
        assertEquals(225, product.getTotalProductsSold());
    }

    
    public void GetAverageSales_WithValidData_ReturnsCorrectValue() {
        String[] names = {"Sealy", "Serta", "Tempur"};
        int[][] sales = {
            {10, 20, 30},
            {15, 25, 35},
            {20, 30, 40}
        };
        Product product = new Product(names, sales);
        assertEquals(75.0, product.getAverageProductsSold(), 0.001);
    }

    public void GetMostPopularProduct_WithValidData_ReturnsCorrectValue() {
        String[] names = {"Sealy", "Serta", "Tempur"};
        int[][] sales = {
            {10, 20, 30},
            {15, 25, 35},
            {20, 30, 40}
        };
        Product product = new Product(names, sales);
        assertEquals("Tempur", product.getMostPopularProduct());
    }
    public void GetMostPopularProduct_WithValidData_ReturnsCorrectValue() {
        String[] names = {"Sealy", "Serta", "Tempur"};
        int[][] sales = {
            {10, 20, 30},
            {15, 25, 35},
            {20, 30, 40}
        };
        Product product = new Product(names, sales);
        assertEquals("Tempur", product.getMostPopularProduct());
    }
}
